INSERT INTO `category` (`name`) VALUES ('художня література');
INSERT INTO `category` (`name`) VALUES ('сучасна література');
INSERT INTO `category` (`name`) VALUES ('книги іноземними мовами');
INSERT INTO `category` (`name`) VALUES ('дитяча література');
INSERT INTO `category` (`name`) VALUES ('саморозвиток. мотивація');
INSERT INTO `category` (`name`) VALUES ('історія');