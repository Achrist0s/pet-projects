INSERT INTO `roles` (`name`) VALUES ('ROLE_user');
INSERT INTO `roles` (`name`) VALUES ('ROLE_Manager');
INSERT INTO `roles` (`name`) VALUES ('ROLE_Admin');