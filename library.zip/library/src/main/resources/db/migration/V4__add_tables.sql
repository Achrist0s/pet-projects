create table roles
(
    id   bigint not null auto_increment,
    name varchar(255),
    primary key (id)
) engine = InnoDB;
create table users_rolesset
(
    users_id    bigint not null,
    rolesset_id bigint not null,
    primary key (users_id, rolesset_id)
) engine = InnoDB;
alter table users_rolesset
    add constraint FKbae8tw2kg6p1ja9cges83x7ha foreign key (rolesset_id) references roles (id);
alter table users_rolesset
    add constraint FKt7213is417582bjg6e95g5w53 foreign key (users_id) references users (id);