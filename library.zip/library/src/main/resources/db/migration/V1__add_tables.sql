create table _order
(
    id        bigint not null auto_increment,
    date      datetime(6),
    delivery  varchar(255),
    status    bit    not null,
    reader_id bigint,
    primary key (id)
) engine = InnoDB;
create table book_in_order
(
    id       bigint  not null auto_increment,
    quantity integer not null,
    book_id  bigint,
    order_id bigint,
    primary key (id)
) engine = InnoDB;
create table books
(
    id           bigint not null auto_increment,
    author       varchar(255),
    availability bit    not null,
    description  varchar(1000),
    title        varchar(255),
    image        varchar(255),
    category_id  bigint,
    primary key (id)
) engine = InnoDB;
create table category
(
    id   bigint not null auto_increment,
    name varchar(255),
    primary key (id)
) engine = InnoDB;
create table readers
(
    id         bigint not null,
    address    varchar(255),
    email      varchar(255),
    first_name varchar(255),
    last_name  varchar(255),
    phone      varchar(255),
    primary key (id)
) engine = InnoDB;
create table users
(
    id       bigint not null auto_increment,
    password varchar(255),
    username varchar(255),
    primary key (id)
) engine = InnoDB;
alter table _order
    add constraint FKm741tvbw64ay1l149ilxul95n foreign key (reader_id) references readers (id);
alter table book_in_order
    add constraint FKd7v0bm0q0aejae9ucn2hyp9y foreign key (book_id) references books (id);
alter table book_in_order
    add constraint FKc4xvfcrv6ebqxudq3u6yj4ieu foreign key (order_id) references _order (id);
alter table books
    add constraint FK8el3ddb59ciucupyc17vu7835 foreign key (category_id) references category (id);
alter table readers
    add constraint FKn5kenaimh48xi6df3d1p1ewa1 foreign key (id) references users (id)