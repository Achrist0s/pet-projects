package com.example.library.service;

import com.example.library.entity.BookInOrder;
import com.example.library.entity.Order;
import com.example.library.repository.BookInOrderRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class BookInOrderService {
    private final BookInOrderRepository bookInOrderRepository;
    public List<BookInOrder> findAllByOrders(Order order){
        return bookInOrderRepository.findAllByOrder(order);
    }
}
