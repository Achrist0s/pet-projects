package com.example.library.repository;

import com.example.library.entity.Book;
import com.example.library.entity.Category;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BookRepository extends JpaRepository<Book, Long> {
    List<Book> findAllByCategories(Category category);
    List<Book> findAllByTitleContainsIgnoreCaseOrderByTitle(String title);
    Page<Book> findAllByCategories(Pageable pageable, Category category);
}
