package com.example.library.service;

import com.example.library.entity.Book;
import com.example.library.entity.Category;
import com.example.library.repository.BookRepository;
import org.springframework.cache.annotation.Cacheable;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class BookService {
    private final BookRepository bookRepository;

    public List<Book> getAllBook(){
        return bookRepository.findAll();
    }

    public List<Book> findBooksByCategory(Category category) {
        return bookRepository.findAllByCategories(category);
    }

    @Cacheable(value = "pageBooks")
    public Page<Book> getPageBooksByCategory(Pageable pageable, Category category){
        return bookRepository.findAllByCategories(pageable, category);
    }

    public void saveBook(String title, String description, String image, String author, boolean availability, Category category){
        Book book = new Book();
        book.setTitle(title);
        book.setAuthor(author);
        book.setDescription(description);
        book.setImage(image);
        book.setAvailability(availability);
        book.setCategories(category);

        bookRepository.save(book);
    }


    public void updateBook(Long id, String title, String description, String image, String author, String availability, Category category){
        Book book = new Book();
        book.setId(id);
        book.setTitle(title);
        book.setAuthor(author);
        book.setDescription(description);
        book.setImage(image);
        book.setAvailability(Boolean.parseBoolean(availability));
        book.setCategories(category);

        bookRepository.save(book);
    }

    public void deleteBook(Long id){
        bookRepository.deleteById(id);
    }


}
