package com.example.library.controller;

import com.example.library.bl.Cart;
import com.example.library.bl.ItemCart;
import com.example.library.entity.*;
import com.example.library.repository.BookInOrderRepository;
import com.example.library.repository.OrderRepository;
import com.example.library.repository.ReaderRepository;
import com.example.library.service.UserService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Date;

@Controller
@RequiredArgsConstructor
public class CartController {

    private final ReaderRepository readerRepository;
    private final OrderRepository orderRepository;
    private final BookInOrderRepository bookInOrderRepository;
    private final UserService userService;

    @GetMapping("/cart")
    public String getPageCart(HttpServletRequest request,
                              Model model) {

        HttpSession session = request.getSession();
        Cart cart = (Cart) session.getAttribute("cart");
        if (cart == null) {
            cart = new Cart();
        }
        model.addAttribute("cart", cart.getCart());
        model.addAttribute("sum", cart.getSumItem());

        return "cart";
    }

    @PostMapping("/addItemToCart")
    public String saveNewItemToCart(@RequestParam(name = "id") Book book,
                                    @RequestParam(name = "quantity") int quantity,
                                    HttpServletRequest request) {

        HttpSession session = request.getSession();
        Cart cart = (Cart) session.getAttribute("cart");
        if (cart == null) cart = new Cart();
        cart.addNewItemToCart(book, quantity);
        session.setAttribute("cart", cart);

        return "redirect:/cart";
    }

    @PostMapping("/updateBookFromCart")
    public String updateProductByCart(@RequestParam(name = "id") Book book,
                                      @RequestParam(name = "quantity") int quantity,
                                      HttpServletRequest request) {

        HttpSession session = request.getSession();
        Cart cart = (Cart) session.getAttribute("cart");
        if (cart == null) cart = new Cart();
        cart.updateItemFromCart(book, quantity);
        session.setAttribute("cart", cart);

        return "redirect:/cart";
    }

    @PostMapping("/deleteBookFromCart")
    public String deleteItemFromCart(@RequestParam(name = "id") Book book,
                                     HttpServletRequest request) {

        HttpSession session = request.getSession();
        Cart cart = (Cart) session.getAttribute("cart");
        if (cart == null) cart = new Cart();
        cart.deleteItemCart(book);
        session.setAttribute("cart", cart);

        return "redirect:/cart";
    }

    @PostMapping("/deleteAllBookFromCart")
    public String deleteAllBookFromCart(HttpServletRequest request) {

        HttpSession session = request.getSession();
        Cart cart = (Cart) session.getAttribute("cart");
        if (cart == null) cart = new Cart();
        cart.deleteAllItemCart();
        session.setAttribute("cart", cart);

        return "redirect:/cart";
    }

    @GetMapping("/order")
    public String getPageOrder(HttpServletRequest request,
                               Model model
    ) {

        HttpSession session = request.getSession();

        Cart cart = (Cart) session.getAttribute("cart");

        if (cart == null) {
            cart = new Cart();
        }

//        Long id = (Long) session.getAttribute("user");

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        Users users = (Users) userService.loadUserByUsername(auth.getName());

        Reader reader = null;
        if (users != null) {
            reader = readerRepository.findById(users.getId()).get();
        } else {
            reader = new Reader();
        }

        model.addAttribute("reader", reader);
        model.addAttribute("cart", cart.getCart());

        return "order";
    }

    @PostMapping("/buy")
    public String buyBook(@RequestParam(name = "delivery") String delivery,
                          HttpServletRequest request) {
        String delivery1 = "";
        if (delivery.equals("1")) {
            delivery1 = "Самовивіз";
        } else if (delivery.equals("2")) {
            delivery1 = "Нова пошта";
        } else {
            delivery1 = "Укрпошта";
        }

        HttpSession session = request.getSession();

//        Long id = (Long) session.getAttribute("user");

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        Users users = (Users) userService.loadUserByUsername(auth.getName());
        Long id = users.getId();

        Cart cart = (Cart) session.getAttribute("cart");

        if (cart == null) return "redirect:/category";

        Reader reader = null;

        if (id != null) {

            reader = readerRepository.findById(id).get();

            Order order = new Order();
            order.setReader(reader);
            order.setDate(new Date());
            order.setDelivery(delivery1);

            Order order1 = orderRepository.save(order);

            for (ItemCart el : cart.getCart()) {
                bookInOrderRepository.save(new BookInOrder(el.getQuantity(), order1, el.getBook()));
            }

            cart.deleteAllItemCart();
            session.setAttribute("cart", cart);

            return "redirect:/thank";
        } else {
            return "redirect:/category";
        }
    }

    @GetMapping("/thank")
    public String getPageThank() {
        return "thank";
    }

}
