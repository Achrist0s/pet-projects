package com.example.library.controller;

import com.example.library.entity.BookInOrder;
import com.example.library.entity.Order;
import com.example.library.service.BookInOrderService;
import com.example.library.service.OrderService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequiredArgsConstructor
public class OrderController {
    private final OrderService orderService;
    private final BookInOrderService bookInOrderService;

    @GetMapping("/order-manager")
    public String getAllOrder(Model model){


        List<Order> orderList = orderService.getAllOrder();

        List<Order> orders1 = orderList.stream().filter(p -> !p.getStatus()).collect(Collectors.toList());
        List<Order> orders2 = orderList.stream().filter( p-> p.getStatus()).collect(Collectors.toList());

        model.addAttribute("orderList1", orders1);
        model.addAttribute("orderList2", orders2);

        return "order-manager";
    }

    @GetMapping("/update-order/{id}")
    public String showOrder(@PathVariable("id") Order order,
                            Model model){

        List<BookInOrder> bookInOrders = bookInOrderService.findAllByOrders(order);
        model.addAttribute("orderList",bookInOrders);

        return "order-manager";
    }


    @PostMapping("updateOrder")
    public String updateOrder(@RequestParam(value = "id") Order order){

        order.setStatus(!order.getStatus() ? true : false);
        orderService.updateOrder(order);

        return "redirect:/order-manager";
    }

}
