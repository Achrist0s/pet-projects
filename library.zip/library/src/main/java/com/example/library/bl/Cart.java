package com.example.library.bl;

import com.example.library.entity.Book;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
public class Cart {
    List<ItemCart> cart;
    private int sumItem;
    public Cart() {
        cart = new ArrayList<>();
        sumItem = 0;
    }

    public synchronized void addNewItemToCart(Book book, int quantity) {
        boolean logic = true;

        for(ItemCart el : cart){
            if(el.getBook().getId()==book.getId()) {
                logic = false;
                el.setQuantity(el.getQuantity()+quantity);
            }
        }

        if(logic) cart.add(new ItemCart(book, quantity));
    }

    public synchronized void updateItemFromCart(Book book, int quantity) {
        if(quantity<=0){
            for(ItemCart el : cart){
                if(el.getBook().getId()==book.getId()){
                    cart.remove(el);
                    break;
                }
            }
        } else {
            for(ItemCart el : cart){
                if(el.getBook().getId()==book.getId()){
                    el.setQuantity(quantity);
                }
            }
        }
    }

    public synchronized void deleteItemCart(Book book) {
        for(ItemCart el : cart){
            if(el.getBook().getId() == book.getId()){
                cart.remove(el);
                break;
            }
        }
    }

    public synchronized void deleteAllItemCart() {
        cart.clear();
        sumItem = 0;
    }

    public synchronized int getSumItem() {
        return cart.size();
    }

}
