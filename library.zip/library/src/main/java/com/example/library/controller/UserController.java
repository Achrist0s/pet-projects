package com.example.library.controller;

import com.example.library.entity.Reader;
import com.example.library.entity.Roles;
import com.example.library.entity.Users;
import com.example.library.repository.ReaderRepository;
import com.example.library.repository.UsersRepository;
import com.example.library.service.UserService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Collections;

@Controller
@RequiredArgsConstructor
public class UserController {

    private final UsersRepository usersRepository;
    private final ReaderRepository readerRepository;
    private final UserService userService;

    @GetMapping("/registration")
    public String getPageRegistration(Model model) {
        model.addAttribute("users", new Users());
        model.addAttribute("reader", new Reader());
        return "registration";
    }

    @PostMapping("/registration")
    public String saveNewUserToDB(@Valid Users user, // username / password
                                  BindingResult bindingResult1,
                                  @Valid Reader reader,
                                  BindingResult bindingResult2
    ) {

        if (bindingResult1.hasErrors()) {
            return "registration";
        }

        if (bindingResult2.hasErrors()) {
            return "registration";
        }

        // Перевірка на username (login)
        if (userService.getLogicUserByUsername(user.getUsername())) {
            return "registration";
        }

        user.setPassword(new BCryptPasswordEncoder().encode(user.getPassword()));

        // Закріплення ролі за користувачем
        user.setPassword(new BCryptPasswordEncoder().encode(user.getPassword()));
        user.setRolesset(Collections.singleton(new Roles(1L, "ROLE_Users")));

        Users user1 = usersRepository.save(user);
        reader.setUser(user1);
        readerRepository.save(reader);


        return "redirect:/login";
    }

//    @PostMapping("/login")
//    public String authUser(@RequestParam(name = "username") String username,
//                           @RequestParam(name = "password") String pass,
//                           HttpServletRequest request) {
//
//
//        if(userService.getLogicUserByUsernameAndPassword(username, pass)){
//
//            return "redirect:/login";
//
//        } else {
//
//            Users user = userService.getUserByUsernameAndPassword(username, pass);
//            HttpSession session = request.getSession();
//            session.setAttribute("user", user.getId());
//
//            return "redirect:/order";
//        }
//    }
}
