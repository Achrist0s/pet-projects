package com.example.library.repository;

import com.example.library.entity.BookInOrder;
import com.example.library.entity.Order;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BookInOrderRepository extends JpaRepository<BookInOrder, Long> {
    List<BookInOrder> findAllByOrder(Order order);
}
