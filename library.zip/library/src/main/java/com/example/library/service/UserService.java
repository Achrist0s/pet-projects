package com.example.library.service;

import com.example.library.entity.Reader;
import com.example.library.entity.Users;
import com.example.library.repository.ReaderRepository;
import com.example.library.repository.UsersRepository;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class UserService implements UserDetailsService{

    private final UsersRepository usersRepository;
    private final ReaderRepository readerRepository;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

        Users user = usersRepository.findByUsername(username);

        if(user==null){
            throw new UsernameNotFoundException("Not found: " + username);
        }

        return user;
    }
    public boolean getLogicUserByUsername(String username){

        return (!usersRepository.findAllByUsername(username).isEmpty()) ? true : false;
    }

    public boolean getLogicUserByUsernameAndPassword(String username, String password){

        return usersRepository.findAllByUsernameAndPassword(username, password).isEmpty() ? true : false;
    }
    public Users getUserByUsernameAndPassword(String username, String password){

        return usersRepository.findAllByUsernameAndPassword(username, password).get(0);
    }

    public Reader getReaderById(Long id){
        return readerRepository.findById(id).get();
    }

    public List<Users> getAllUsers(){
        return usersRepository.findAll();
    }

    public void updateUser(String password, String username, Long id){
        usersRepository.updateUserById(password, username, id);
    }

    public void addNewRoleToUser(Long userId, Long roleId){
        usersRepository.updateRoleByUserId(userId, roleId);
    }
}
