package com.example.library.controller;
import com.example.library.entity.Category;
import com.example.library.repository.BookRepository;
import com.example.library.service.BookService;
import com.example.library.service.CategoryService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequiredArgsConstructor
public class InfoController {

    private final CategoryService categoryService;
    private final BookService bookService;
    private final BookRepository bookRepository;

    @GetMapping("/readingrooms")
    public String getPageReadingRooms(){
        return "readingrooms";
    }

    @GetMapping("/delivery")
    public String getPageDelivery(){
        return "delivery";
    }

    @GetMapping("/info")
    public String getPageInfo(){
        return "info";
    }

    @GetMapping("/login")
    public String getPageLogin(){
        return "auth";
    }

    @GetMapping("/category")
    public String getPageCategory(Model model){
        model.addAttribute("categories", categoryService.getAllCategory());
        return "category";
    }

    @GetMapping("/category/{id}")
    public String getBooksByCategory(@PathVariable("id")Category category,
                                     Model model,
                                     @PageableDefault(sort = {"id"}, direction = Sort.Direction.ASC, size = 4)
                                         Pageable pageable){
        model.addAttribute("page", bookService.getPageBooksByCategory(pageable, category));
        model.addAttribute("url", "/category/"+category.getId());
        return "books";
    }

    @GetMapping("/search")
    public String getPageResultSearchBookByTitle(@RequestParam(name = "search") String title,
                                                 Model model){
        model.addAttribute("bookByTitle", bookRepository.findAllByTitleContainsIgnoreCaseOrderByTitle(title));
        return "search";
    }
    @GetMapping("/user")
    public String getUserPage(){
        return "user";
    }


    @GetMapping("/manager")
    public String getManagerPage(){
        return "manager";
    }


    @GetMapping("/admin")
    public String getAdminPage(){
        return "admin";
    }
}
