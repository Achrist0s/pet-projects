package com.example.library;

import com.example.library.entity.Roles;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import com.example.library.repository.RolesRepository;

@SpringBootApplication
@EnableCaching
@RequiredArgsConstructor
public class Main {

    private final RolesRepository rolesRepository;

    public static void main(String[] args) {
        SpringApplication.run(Main.class, args);
    }

    @Bean
    CommandLineRunner run(){

        return args -> {

            if(rolesRepository.findAll().isEmpty()){
                rolesRepository.save(new Roles(1L, "ROLE_User"));
                rolesRepository.save(new Roles(2L, "ROLE_Manager"));
                rolesRepository.save(new Roles(3L, "ROLE_Admin"));
            }
        };

    }

}
