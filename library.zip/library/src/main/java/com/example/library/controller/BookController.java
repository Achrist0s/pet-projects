package com.example.library.controller;

import com.example.library.entity.Category;
import com.example.library.service.BookService;
import com.example.library.service.CategoryService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequiredArgsConstructor
public class BookController {

    private final BookService bookService;
    private final CategoryService categoryService;

    @GetMapping("/book-manager")
    public String getAllProduct(Model model){

        model.addAttribute("allCategory", categoryService.getAllCategory());
        model.addAttribute("books", bookService.getAllBook());

        return "book-manager";
    }


    @PostMapping("saveBook")
    public String saveProduct(@RequestParam(value = "title") String title,
                              @RequestParam(value = "description") String description,
                              @RequestParam(value = "author") String author,
                              @RequestParam(value = "category_id") Category category,
                              @RequestParam(value = "image") String image,
                              @RequestParam(value = "availability") boolean availability
    ){
        bookService.saveBook(title, description, image, author, availability, category);
        return "redirect:/book-manager";
    }


    @PostMapping("updateBook")
    public String updateBook(@RequestParam(value = "id") Long id,
                             @RequestParam(value = "title") String title,
                             @RequestParam(value = "description") String description,
                             @RequestParam(value = "author") String author,
                             @RequestParam(value = "category_id") Category category,
                             @RequestParam(value = "image") String image,
                             @RequestParam(value = "availability") String availability
    ){
        bookService.updateBook(id, title, description, image, author, availability, category);
        return "redirect:/book-manager";
    }

    @PostMapping("deleteBook")
    public String deleteBook(@RequestParam(value = "id") Long id){
        bookService.deleteBook(id);
        return "redirect:/book-manager";
    }

}
