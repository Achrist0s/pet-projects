package com.example.library.service;

import com.example.library.entity.Category;
import com.example.library.repository.CategoryRepository;
import jakarta.persistence.Cacheable;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class CategoryService {
    private final CategoryRepository categoryRepository;
    public List<Category> getAllCategory(){
        return categoryRepository.findAll();
    }
    public void saveCategory(String name) {
        Category category = new Category();
        category.setName(name);

        categoryRepository.save(category);
    }

    public void updateCategory(Long id, String name) {
        Category category = new Category();
        category.setId(id);
        category.setName(name);

        categoryRepository.save(category);
    }

    public void deleteCategory(Long id){
        categoryRepository.deleteById(id);
    }

    public Optional<Category> findCategoryById(Long id){
        Optional<Category> category = categoryRepository.findById(id);
        return category;
    }

}
